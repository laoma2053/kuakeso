import { MetadataRoute } from 'next';
import { prisma } from '@/lib/prisma';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://example.com';

  // Static pages
  const staticPages: MetadataRoute.Sitemap = [
    {
      url: baseUrl,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 1,
    },
    {
      url: `${baseUrl}/about`,
      lastModified: new Date(),
      changeFrequency: 'monthly',
      priority: 0.5,
    },
  ];

  // Dynamic resource pages (latest 500)
  const resources = await prisma.resource.findMany({
    where: { status: 'active' },
    orderBy: { createdAt: 'desc' },
    take: 500,
    select: { slug: true, updatedAt: true },
  });

  const resourcePages: MetadataRoute.Sitemap = resources.map((r) => ({
    url: `${baseUrl}/res/${r.slug}`,
    lastModified: r.updatedAt,
    changeFrequency: 'weekly' as const,
    priority: 0.7,
  }));

  return [...staticPages, ...resourcePages];
}
